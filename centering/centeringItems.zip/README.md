## Centering list items, responsively

A lightweight jQuery plugin that centers list items within a container

### Example

You can see an <a href="http://benholland.me/labs/centering/">example here</a>